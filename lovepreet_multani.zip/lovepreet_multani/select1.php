<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "library";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT * FROM Admin_master";
$result = $conn->query($sql);



if ($result->num_rows > 0) {
    // output data of each row
    echo "<table border=1>
	<tr>
	<th>Id</th>
	<th>Name</th>
	<th>Gender</th>
	<th>Address</th>
	
	<th>City</th>
	<th>Province</th>
	<th>Postalcode</th>
	
	<th>JoiningDate</th>
	
	</tr>";
    while($row = $result->fetch_assoc()) {
		
		echo "<tr>";
		echo "<td>" . $row['Admin_id'] . "</td>";
		echo "<td>" . $row['Admin_Name'] . "</td>";
		echo "<td>" . $row['Gender'] . "</td>";
		echo "<td>" . $row['Address'] . "</td>";
		
		echo "<td>" . $row['City'] . "</td>";
		echo "<td>" . $row['Province'] . "</td>";
		echo "<td>" . $row['Postalcode'] . "</td>";
		
		echo "<td>" . $row['JoiningDate'] . "</td>";
	
		echo "</tr>";
        //echo "<tr><td>". $row["id"] . "</td><td>" . $row["Name"] . "</td><td>" . $row["Address"]. "</td></tr>";
    }
    echo "</table>";
} else {
    echo "0 results";
}
$conn->close();
?>