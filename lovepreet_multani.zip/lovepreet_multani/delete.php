 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "library";


// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//delete from admin_master;
$sql = "DELETE FROM admin_master WHERE Admin_id=6";


if ($conn->query($sql) === TRUE) {
    echo "Record delete successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}


//delete from book_master1;
$sql = "DELETE FROM book_master1 WHERE Admin_id=7";


if ($conn->query($sql) === TRUE) {
    echo "Record delete successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}


//delete from return_master;
$sql = "DELETE FROM return_master WHERE book_id=15";


if ($conn->query($sql) === TRUE) {
    echo "Record delete successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}

//delete from student_master;
$sql = "DELETE FROM student_master WHERE student_id=6";


if ($conn->query($sql) === TRUE) {
    echo "Record delete successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}


//delete from library_user_master;
$sql = "DELETE FROM library_user_master WHERE user_id=6";


if ($conn->query($sql) === TRUE) {
    echo "Record delete successfully";
} else {
    echo "Error deleting record: " . $conn->error;
}
$conn->close();
?>