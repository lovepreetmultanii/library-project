 <?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "library";


// Create connection
$conn = new mysqli($servername, $username, $password,$dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

 //update table admin_master;
$sql = "UPDATE admin_master SET Gender='Male' WHERE Admin_id=4";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

//update table book_master1;
$sql = "UPDATE book_master1 SET id='9' WHERE publisher='informa'";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

//update table return_master;
$sql = "UPDATE return_master SET to_date='2017/05/18' WHERE book_id=3";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}

//update table student_master;
$sql = "UPDATE student_master SET City='Brampton' WHERE student_id=3";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}



//update table library_user_master;
$sql = "UPDATE library_user_master SET password='4567' WHERE user_id=3";

if ($conn->query($sql) === TRUE) {
    echo "Record updated successfully";
} else {
    echo "Error updating record: " . $conn->error;
}








$conn->close();
?>