<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "Library";


// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if(isset($_POST['update'])){
	$UpdateQuery = "UPDATE Admin_Master SET Admin_id='$_POST[id]', Admin_Name='$_POST[name]', Gender='$_POST[gender]' WHERE id='$_POST[hidden]'";
	mysql_query($UpdateQuery,$conn);

	
};


	if(isset($_POST['delete'])){
	$DeleteQuery = "DELETE FROM Admin_master  WHERE id='$_POST[hidden]'";
	mysql_query($DeleteQuery,$conn);


	};


	
	
//TABLE ADMIN_MASTER;	
	echo "<h3> ADMIN_MASTER:-</h3>";
$sql = "SELECT * FROM Admin_Master";
$result = $conn->query($sql);





    echo "<table border=1>
	<tr>
	<th>Id</th>
	<th>Name</th>
	<th>Gender</th>
	<th>Address</th>
	
	<th>City</th> 
	<th>Province</th>
	<th>Postalcode</th>
	
	<th>JoiningDate</th>
	
	</tr>";

    while($row = $result->fetch_assoc()) {
		
		echo "<form action=myDB1.php method=post>";
		echo "<tr>";
		echo "<td>" . "<input type=text name=id value=" . $row['Admin_id'] . " </td>";
		echo "<td>" . "<input type=text name=name value=" . $row['Admin_Name'] . " </td>";
		echo "<td>" . "<input type=text name=gender value=" . $row['Gender'] . " </td>";
		echo "<td>" . "<input type=text name=address value=" . $row['Address'] . " </td>";
		
		echo "<td>" . "<input type=text name=city value=" . $row['City'] . " </td>";
		echo "<td>" . "<input type=text name=province value=" . $row['Province'] . " </td>";
		echo "<td>" . "<input type=text name=postalcode value=" . $row['Postalcode'] . " </td>";
		
		echo "<td>" . "<input type=text name=joining_date value=" . $row['JoiningDate'] . " </td>";
		
		
		
		
		
		
		
		
		
	    echo "<td>" . "<input type=hidden name=hidden value=" . $row['Admin_id'] . " </td>";
		echo "<td>" . "<input type=submit name=update value=update" . " </td>";
			echo "<td>" . "<input type=submit name=delete value=delete" . " </td>";
			echo "</tr>";
		
		
     echo "</form>";   
    }
    echo "</table><br><br><br>";
	
	
	
	
	
	//TABLE BOOK_MASTER1;
	
	
	echo "<h3> BOOK_MASTER1:-</h3>";
	$sql = "SELECT * FROM book_master1";
$result = $conn->query($sql);





    echo "<table border=1>
	<tr>
	<th>Id</th>
	<th>Title</th>
	<th>Author</th>
	<th>Publisher</th>
	
	<th>Edition</th>
	<th>ISBN_Number</th>
	<th>Price</th>
	
	<th>Total</th>
	
	</tr>";

    while($row = $result->fetch_assoc()) {
		echo "<form action=myDB1.php method=post>";
		echo "<tr>";
		echo "<td>" . "<input type=text name=id value=" . $row['id'] . " </td>";
		echo "<td>" . "<input type=text name=title value=" . $row['Book_title'] . " </td>";
		echo "<td>" . "<input type=text name=author value=" . $row['Author'] . " </td>";
		echo "<td>" . "<input type=text name=publisher value=" . $row['Publisher'] . " </td>";
		
		echo "<td>" . "<input type=text name=edition value=" . $row['Edition'] . " </td>";
		echo "<td>" . "<input type=text name=isbn_no value=" . $row['ISBN_No'] . " </td>";
		echo "<td>" . "<input type=text name=price value=" . $row['price'] . " </td>";
		
		echo "<td>" . "<input type=text name=total value=" . $row['Total_no_of_copies'] . " </td>";
		
		
		
		
		
		
		
		
		
	    echo "<td>" . "<input type=hidden name=hidden value=" . $row['id'] . " </td>";
		echo "<td>" . "<input type=submit name=update value=update" . " </td>";
			echo "<td>" . "<input type=submit name=delete value=delete" . " </td>";
			echo "</tr>";
		
		
     echo "</form>";   
    }
    echo "</table ><br><br><br>";
	
	
	
	//TABLE RETURN_MASTER;
	
	
	echo "<h3> RETURN_MASTER:-</h3>";
		
	$sql = "SELECT * FROM return_master";
$result = $conn->query($sql);





    echo "<table border=1>
	<tr>
	<th>BookId</th>
	<th>StudentId</th>
	<th>FromDate</th>
	<th>ToDate</th>
	
	<th>Description</th>
	
	</tr>";

    while($row = $result->fetch_assoc()) {
		echo "<form action=myDB1.php method=post>";
		echo "<tr>";
		echo "<td>" . "<input type=text name=Book_id value=" . $row['book_id'] . " </td>";
		echo "<td>" . "<input type=text name=Student_id value=" . $row['student_id'] . " </td>";
		echo "<td>" . "<input type=text name=from_date value=" . $row['from_date'] . " </td>";
		echo "<td>" . "<input type=text name=publisher value=" . $row['to_date'] . " </td>";
		
		echo "<td>" . "<input type=text name=description value=" . $row['description'] . " </td>";
		
		
		
		
		
		
		
		
		
		
	    echo "<td>" . "<input type=hidden name=hidden value=" . $row['book_id'] . " </td>";
		echo "<td>" . "<input type=submit name=update value=update" . " </td>";
			echo "<td>" . "<input type=submit name=delete value=delete" . " </td>";
			echo "</tr>";
		
		
     echo "</form>";    
    }
    echo "</table>";
	

$conn->close();
?>